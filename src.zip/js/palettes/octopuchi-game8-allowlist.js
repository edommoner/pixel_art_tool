// 網羅版 allowlist（octopuchi 掲載系を広くカバー）
// Game8 の色系統キー: white,yellow,orange,red,pink,purple,blue,green,brown,gray,black,transparent,other

export const GAME8_COLOR_LABELS_JA = {
  white: "白",
  yellow: "黄",
  orange: "橙",
  red: "赤",
  pink: "ピンク",
  purple: "紫",
  blue: "青",
  green: "緑",
  brown: "茶",
  gray: "灰",
  black: "黒",
  transparent: "透明",
  other: "その他",
};

function push(list, label, category, ids) {
  list.push({ label, category, ids });
}

// 16色 → Game8カテゴリへの対応
const COLOR_TO_CAT = {
  white: "white",
  light_gray: "gray",
  gray: "gray",
  black: "black",
  brown: "brown",
  red: "red",
  orange: "orange",
  yellow: "yellow",
  lime: "green",
  green: "green",
  cyan: "blue",
  light_blue: "blue",
  blue: "blue",
  purple: "purple",
  magenta: "pink",
  pink: "pink",
};
const COLOR_LABEL_JA = {
  white: "白色",
  light_gray: "薄灰色",
  gray: "灰色",
  black: "黒色",
  brown: "茶色",
  red: "赤色",
  orange: "橙色",
  yellow: "黄色",
  lime: "黄緑色",
  green: "緑色",
  cyan: "青緑色",
  light_blue: "空色",
  blue: "青色",
  purple: "紫色",
  magenta: "赤紫色",
  pink: "桃色",
};
const COLORS_16 = [
  "white",
  "light_gray",
  "gray",
  "black",
  "brown",
  "red",
  "orange",
  "yellow",
  "lime",
  "green",
  "cyan",
  "light_blue",
  "blue",
  "purple",
  "magenta",
  "pink",
];

// 色付き素材の一括生成
function genDyedSet(list) {
  const types = [
    { key: "wool", ja: "羊毛", id: (c) => `minecraft:${c}_wool` },
    {
      key: "concrete",
      ja: "コンクリート",
      id: (c) => `minecraft:${c}_concrete`,
    },
    {
      key: "concrete_powder",
      ja: "コンクリートパウダー",
      id: (c) => `minecraft:${c}_concrete_powder`,
    },
    // terracotta は light_gray など一部特殊名あり
    {
      key: "terracotta",
      ja: "テラコッタ",
      id: (c) => `minecraft:${c}_terracotta`,
    },
    {
      key: "glazed_terracotta",
      ja: "彩釉テラコッタ",
      id: (c) => `minecraft:${c}_glazed_terracotta`,
    },
    {
      key: "shulker_box",
      ja: "シュルカーボックス",
      id: (c) => `minecraft:${c}_shulker_box`,
    },
    {
      key: "stained_glass",
      ja: "色付きガラス",
      id: (c) => `minecraft:${c}_stained_glass`,
    },
    { key: "carpet", ja: "カーペット", id: (c) => `minecraft:${c}_carpet` },
  ];
  for (const c of COLORS_16) {
    const cat = COLOR_TO_CAT[c] || "other";
    for (const t of types) {
      const id = t.id(c);
      const label = `${COLOR_LABEL_JA[c]}の${t.ja}`;
      push(list, label, cat, [id]);
    }
  }
  // 無着色テラコッタ（茶）
  push(list, "テラコッタ", "brown", ["minecraft:terracotta"]);
}

// 木材・原木・樹皮を剥いだ原木/wood
function genWoodSet(list) {
  const woods = [
    ["oak", "オーク"],
    ["spruce", "トウヒ"],
    ["birch", "シラカバ"],
    ["jungle", "ジャングル"],
    ["acacia", "アカシア"],
    ["dark_oak", "ダークオーク"],
    ["mangrove", "マングローブ"],
  ];
  for (const [en, ja] of woods) {
    push(list, `${ja}の板材`, "brown", [`minecraft:${en}_planks`]);
    push(list, `${ja}の原木`, "brown", [`minecraft:${en}_log`]);
    push(list, `樹皮を剥いだ${ja}の木`, "brown", [
      `minecraft:stripped_${en}_log`,
      `minecraft:stripped_${en}_wood`,
    ]);
    push(list, `${ja}の木`, "brown", [`minecraft:${en}_wood`]);
  }
}

// 葉
function genLeaves(list) {
  const leaves = [
    "oak",
    "spruce",
    "birch",
    "jungle",
    "acacia",
    "dark_oak",
    "mangrove",
    "azalea",
  ];
  const jaMap = {
    oak: "オーク",
    spruce: "トウヒ",
    birch: "シラカバ",
    jungle: "ジャングル",
    acacia: "アカシア",
    dark_oak: "ダークオーク",
    mangrove: "マングローブ",
    azalea: "ツツジ",
  };
  for (const en of leaves) {
    push(list, `${jaMap[en]}の葉`, "green", [`minecraft:${en}_leaves`]);
  }
}

// ニュートラル/黄系・白系など（装飾＆自然）
function genNeutrals(list) {
  push(list, "骨", "white", ["minecraft:bone_block"]);
  push(list, "キノコの柄", "white", ["minecraft:mushroom_stem"]);
  push(list, "エンドストーン", "yellow", ["minecraft:end_stone"]);
  push(list, "エンドストーンレンガ", "yellow", ["minecraft:end_stone_bricks"]);
  push(list, "スポンジ", "yellow", ["minecraft:sponge"]);
  push(list, "濡れたスポンジ", "yellow", ["minecraft:wet_sponge"]);
  push(list, "ハニカムブロック", "yellow", ["minecraft:honeycomb_block"]);
  push(list, "金ブロック", "yellow", ["minecraft:gold_block"]);
  push(list, "金の原石ブロック", "yellow", ["minecraft:raw_gold_block"]);
  push(list, "エメラルドブロック", "green", ["minecraft:emerald_block"]);
  push(list, "ラピスラズリブロック", "blue", ["minecraft:lapis_block"]);
  push(list, "固めた泥", "brown", ["minecraft:packed_mud"]);
  push(list, "滑らかな砂岩", "brown", ["minecraft:smooth_sandstone"]);
  push(list, "赤い砂岩", "orange", ["minecraft:red_sandstone"]);
  push(list, "赤い砂", "orange", ["minecraft:red_sand"]);
  push(list, "苔ブロック", "green", ["minecraft:moss_block"]);
  push(list, "スイカ", "green", ["minecraft:melon"]);
  // きのこ
  push(list, "茶色のキノコブロック", "brown", [
    "minecraft:brown_mushroom_block",
  ]);
  push(list, "赤色のキノコブロック", "red", ["minecraft:red_mushroom_block"]);
}

// 銅系（明るい橙～赤茶系に寄ることが多い）
function genCopper(list) {
  const ids = [
    "copper_block",
    "exposed_copper",
    "cut_copper",
    "exposed_cut_copper",
    "waxed_copper_block",
    "waxed_exposed_copper",
    "waxed_cut_copper",
    "waxed_exposed_cut_copper",
  ];
  for (const id of ids) push(list, "銅系", "orange", [`minecraft:${id}`]);
}

export const OCTOPUCHI_ALLOWLIST = (() => {
  const out = [];
  genDyedSet(out);
  genWoodSet(out);
  genLeaves(out);
  genNeutrals(out);
  genCopper(out);
  return out;
})();
